.. _ga:

Genetic algorithm details
=======================================

The genetic algorithm searchs for the optimal rule base for a problem. The criteria used to determine optimal is the one mentioned in :ref:`step3`:

1. Matthew Correlation Coefficient: it is a metric that ranges from [-1, 1] that measures the quality of a classification performance. It less sensible to imbalance classification than the standard accuracy.
2. Dominance scores: are related to the support and confidence of each rule. So, rules that do not significantly fire or that are not discriminative are penalized. Thos that have a value less than the `tolerance` parmeter are dleted fro mthe rule base.
3. Small preference: rule bases with less rules and less antecedents are prefered.

In order to understand dominance scores, we recommend reading the following paper:
Antonelli, M., Bernardo, D., Hagras, H. & Marcelloni, F. Multiobjective evolutionary optimization of type-2 fuzzy rule-based systems for financial data classification. IEEE Trans. Fuzzy Syst. 25, 249–264 (2017)

---------------------------------------
Limitations of the optimization process
---------------------------------------

- General Type 2 requires precomputed fuzzy partitions.
- When optimizing IV fuzzy partitions: Not all possible shapes of trapezoids all supported. Optimized trapezoids will always have max memberships for the lower and upper bounds in the same points. Height of the lower membership is optimized by scaling. Upper membership always reaches 1 at some point.

-----------------
Fitness functions
-----------------

The fitness function is a convex combination of two different scores. The Matthew Correlation Coefficient and a small size preference.
The small size preference is computed as:

.. math::
    1 - \frac{\text{antecedents used}}{\text{total antecedents possible}}

In this way, if the rule base uses 0 antecedents it would perfect according to this criteria, and a rule base that used the max number of antecedents in each rule would be considered the worst.
Of course, extreme cases such as using 0 antecedents are not desirable, but they are not problematic since the first fitness criteria would discard empty or useless rule base.

The convex combination is set to put 99% of importance to the Matthew Correlation Coefficient and 1% to the size preference, so that this loss is only used in draws. For more information about
changing this fitness function check :ref:`extending`.
