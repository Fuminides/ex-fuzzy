Fuzzy Rules Functions
=====================

.. automodule:: ex_fuzzy.rules
    :members: