Classification evaluation tools
===============================

.. automodule:: ex_fuzzy.eval_tools
    :members: