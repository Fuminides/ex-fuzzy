T2 Centroid compute
====================

.. automodule:: ex_fuzzy.centroid
    :members: