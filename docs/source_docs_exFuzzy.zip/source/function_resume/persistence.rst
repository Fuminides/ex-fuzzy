Classification persistence
===============================

.. automodule:: ex_fuzzy.persistence
    :members: