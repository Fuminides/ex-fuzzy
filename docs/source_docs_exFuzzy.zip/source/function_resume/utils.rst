Partition utils
====================

.. automodule:: ex_fuzzy.utils
    :members: